<div class="navigation">
	<div class="next"><?php next_posts_link(__('Older Entries &raquo;', 'base')) ?></div>
	<div class="prev"><?php previous_posts_link(__('&laquo; Newer Entries', 'base')) ?></div>
</div>
