<div class="navigation">
	<div class="next"><?php previous_post_link(__('%link &raquo;', 'base')) ?></div>
	<div class="prev"><?php next_post_link(__('&laquo; %link', 'base')) ?></div>
</div>