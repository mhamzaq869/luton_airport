<?php get_header(); ?>
<div id="notfound">
		<div class="notfound">
    		<div class="container">
        			<div class="notfound-404">
        			    <a class="back-home" href="https://lutonairport.taxi/">Back To Home</a>
        				<h1>4<span>0</span>4</h1>
        			</div>
        			<div class="main-title">
        			    <h2>Hmm..Looks like this page got lost! Or eaten..</h2>
        			</div>
        			<p>The link you followed is  either lost, incorrect or the page has been removed! </p>
        			<div class="social-icon">
            			<a href="#"><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
            			<a href="#"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
            			<a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
        			</div>
    		</div>
    	</div>
	</div>
<?php get_footer(); ?>

